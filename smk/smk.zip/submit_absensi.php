<?php
// submit_absensi.php
$host = 'cloud.hypercloudhost.com';
$db = 'ppexbjum_smk09';
$user = 'ppexbjum_DanadyaksaFadhilaVirgiawan09';
$pass = 'BeyondGenomb00';
$conn = new mysqli( $host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);

}

$nisn = $_POST['nisn'];
$status = $_POST['status'];
$date = date('Y-m-d'); // tanggal saat ini

$sql = "INSERT INTO absensi (nisn, id_absen, tanggal_absensi) VALUES ('$nisn', '$status', '$date')";

if ($conn->query($sql) === TRUE) {
    echo "Absensi berhasil disimpan.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

<!-- Back Button -->
<br>
<a href=" index.php">
    <button style="padding: 10px; background-color:rgb(6, 238, 255); color: black; border: none; border-radius: 5px; cursor: pointer;">
        Return to Home Page
    </button>
</a>